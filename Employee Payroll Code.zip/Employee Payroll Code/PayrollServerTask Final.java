package com.mycompany.paymanagementsys;

import java.io.*;
import java.net.Socket;
import java.net.InetAddress;
import java.util.Scanner;
import java.io.IOException;
import java.util.Iterator;

/**
 *
 * @author cdeets
 */
public class PayrollServerTask implements Runnable 
{
    private final Socket socket;
	
    /**
     *
     * @param socket
     */
    public PayrollServerTask(Socket socket)
    {
        this.socket = socket;

    }    

    /**
     *
     */
    @Override
    public void run()
    {
        try
        {	
            InetAddress clientAddress = socket.getInetAddress();
            System.out.println("Client's IP address is "
                    + clientAddress.getHostAddress());

            PrintWriter outToClient = new PrintWriter(
                    socket.getOutputStream());
            Scanner inFromClient = new Scanner(
                    socket.getInputStream());
            
            String username = inFromClient.nextLine();
            System.out.println(username);
            String password = inFromClient.nextLine();
            System.out.println(password);

            outToClient.flush();
            socket.close();          
        }
        catch (IOException e)
        {
            System.err.println(e);
        }
    }
}
