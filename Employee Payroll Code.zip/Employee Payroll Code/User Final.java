package com.mycompany.paymanagementsys;

import java.io.Serializable;
/**
 *
 * @author kdkinkade
 */
public class User implements Serializable
{

    /**
     *
     */
    protected  String name;

    /**
     *
     */
    protected  String employeeID;

    /**
     *
     */
    protected  int positionNum;

    /**
     *
     */
    protected  String socialSecurityNum;

    /**
     *
     */
    protected  double salary;

    /**
     *
     */
    protected  double taxWithheld;

    /**
     *
     */
    protected  String bankAccountNum;

    /**
     *
     */
    protected  String bankName;

    /**
     *
     */
    protected  String username;

    /**
     *
     */
    protected  String password;

    /**
     *
     */
    protected  String email;

    /**
     *
     */
    protected  String address;

    /**
     *
     */
    protected  boolean lifeIns;

    /**
     *
     */
    protected  boolean healthIns;

    /**
     *
     */
    protected  boolean retirement;

    /**
     *
     */
    protected  boolean isAdmin;

    /**
     *
     */
    protected  double vacationHours;

    /**
     *
     */
    protected  double personalHours;

    /**
     *
     */
    protected  double sickHours;
    
    /**
     *
     * @param name
     * @param employeeID
     * @param positionNum
     * @param socialSecurityNum
     * @param salary
     * @param taxWithheld
     * @param bankAccountNum
     * @param bankName
     * @param username
     * @param password
     * @param email
     * @param address
     * @param lifeIns
     * @param healthIns
     * @param retirement
     * @param isAdmin
     * @param vacationHours
     * @param personalHours
     * @param sickHours
     */
    public User(String name, String employeeID, int positionNum,
        String socialSecurityNum, double salary, double taxWithheld, String bankAccountNum, String bankName,
        String username, String password, String email, String address, boolean lifeIns, boolean healthIns, 
        boolean retirement, boolean isAdmin, double vacationHours, double personalHours, double sickHours)
        {
    
        this.name = name;
	this.employeeID = employeeID;
        this.positionNum = positionNum;
        this.socialSecurityNum = socialSecurityNum;
        this.salary = salary;
        this.taxWithheld = taxWithheld;
        this.bankAccountNum = bankAccountNum;
        this.bankName = bankName;
        this.username = username;
        this.password = password;
        this.email = email;
        this.address = address;
        this.lifeIns = lifeIns;
        this.healthIns = healthIns;
        this.retirement = retirement;
        this.isAdmin = isAdmin;
        this.vacationHours = vacationHours;
        this.personalHours = personalHours;
        this.sickHours = sickHours;
        }
    
    /**
     *
     * @return
     */
    public String getName()
    {
        return name;
    }

    /**
     *
     * @return
     */
    public String getEmployeeID()
    {
        return employeeID;
    }
	
    /**
     *
     * @return
     */
    public int getPositionNum()
    {
        return positionNum;
    }

    /**
     *
     * @return
     */
    public String getSocialSecurityNum()
    {
        return socialSecurityNum;
    }

    /**
     *
     * @return
     */
    public double getSalary()
    {
            return salary;
    }

    /**
     *
     * @return
     */
    public double getTaxWithheld()
    {
        return taxWithheld;
    }
    
    /**
     *
     * @return
     */
    public String getBankName()
    {
        return bankName;
    }
     
    /**
     *
     * @param username
     */
    public void setUsername(String username)
    {
        this.username = username;
    }
    
    /**
     *
     * @return
     */
    public String getUsername()
    {
        return username;
    }
       
    /**
     *
     * @param password
     */
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    /**
     *
     * @return
     */
    public String getPassword()
    {
        return password;
    }
    
    /**
     *
     * @return
     */
    public String getEmail()
    {
        return email;
    }
    
    /**
     *
     * @return
     */
    public String getAddress()
    {
        return address;
    }
    
    /**
     *
     * @return
     */
    public boolean getLifeIns()
    {
        return lifeIns;
    }

    /**
     *
     * @return
     */
    public boolean getHealthIns()
    {
        return healthIns;
    }

    /**
     *
     * @return
     */
    public boolean getRetirement()
    {
        return retirement;
    }

    /**
     *
     * @return
     */
    public boolean getIsAdmin()
    {
        return isAdmin;
    }

    /**
     *
     * @return
     */
    public double getVacationHours()
    {
        return vacationHours;
    }

    /**
     *
     * @return
     */
    public double getPersonalHours()
    {
        return personalHours;
    }

    /**
     *
     * @return
     */
    public double getSickHours()
    {
        return sickHours;
    }
    
    /**
     *
     * @param name
     */
    public void setName(String name)
    {
        this.name = name;
    }
    
    /**
     *
     * @param employeeID
     */
    public void setEmployeeID(String employeeID)
    {
        this.employeeID  = employeeID;
    }

    /**
     *
     * @param positionNum
     */
    public void setPositionNum(int positionNum)
    {
        this.positionNum = positionNum;
    }

    /**
     *
     * @param socialSecurityNum
     */
    public void setSocialSecurityNum(String socialSecurityNum)
    {
        this.socialSecurityNum = socialSecurityNum;
    }

    /**
     *
     * @param salary
     */
    public void setSalary(double salary)
    {
        this.salary = salary;
    }

    /**
     *
     * @param taxWithheld
     */
    public void setTaxWithheld(double taxWithheld)
    {
        this.taxWithheld = taxWithheld;
    }

    /**
     *
     * @param bankName
     */
    public void setBankName(String bankName)
    {
        this.bankName = bankName;
    }

    /**
     *
     * @param bankAccountNum
     */
    public void setBankAccountNum(String bankAccountNum)
    {
        this.bankAccountNum = bankAccountNum;
    }

    /**
     *
     * @return
     */
    public  String getBankAccountNum()
    {
        return bankAccountNum;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email)
    {
        this.email = email;
    }

    /**
     *
     * @param address
     */
    public void setAddress(String address)
    {
        this.address = address;
    }

    /**
     *
     * @param lifeIns
     */
    public void setLifeIns(boolean lifeIns)
    {
        this.lifeIns = lifeIns;
    }

    /**
     *
     * @param healthIns
     */
    public void setHealthIns(boolean healthIns)
    {
        this.healthIns = healthIns;
    }

    /**
     *
     * @param retirement
     */
    public void setRetirement(boolean retirement)
    {
        this.retirement = retirement;
    }

    /**
     *
     * @param adminAccess
     */
    public void setIsAdmin(boolean adminAccess)
    {
        this.isAdmin = isAdmin;
    }

    /**
     *
     * @param vacationHours
     */
    public void setVacationHours(double vacationHours)
    {
        this.vacationHours = vacationHours;
    }

    /**
     *
     * @param personalHours
     */
    public void setPersonalHours(double personalHours)
    {
        this.personalHours = personalHours;
    }

    /**
     *
     * @param sickHours
     */
    public void setSickHours(double sickHours)
    {
        this.sickHours = sickHours;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString()
    {
        return name + ", " + employeeID + ", " + email +
                ", " + username + ", " + password + ", " + address;
    }
}

