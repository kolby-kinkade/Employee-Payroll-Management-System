/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.paymanagementsys;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kdkinkade
 */
public class EmployeeDatabaseTest {
    
    
    private User testUser = new User("John Doe", "123456", 1, "545-85-7894",
        90000, .24, "654321", "USSSA", "johnDoe1", "johnTheDeer1",
        "john.doe@mariobros.com", "42 Wallaby Way, Sydney 78910", true, false,
        true, false, 80, 40, 80);
    
    
    public EmployeeDatabaseTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of isUser method, of class EmployeeDatabase.
     */
    @Test
    public void testIsUser() {
        System.out.println("isUser");
        String username = "";
        String password = "";
        EmployeeDatabase instance = new EmployeeDatabase();
        boolean expResult = false;
        boolean result = instance.isUser(username, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of trueAdmin method, of class EmployeeDatabase.
     */
    @Test
    public void testTrueAdmin() {
        System.out.println("trueAdmin");
        String username = "";
        String password = "";
        EmployeeDatabase instance = new EmployeeDatabase();
        boolean expResult = false;
        boolean result = instance.trueAdmin(username, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of addEmployee method, of class EmployeeDatabase.
     */
    @Test
    public void testAddEmployee() throws Exception {
        EmployeeDatabase testDB = new EmployeeDatabase();
        Set<User> testSet = new HashSet<>();
        boolean complete = false;
        testDB.addEmployee(testUser);
        complete = true;
        
        assertTrue(complete);
    }

    /**
     * Test of getEmployeeID method, of class EmployeeDatabase.
     */
    @Test
    public void testGetEmployeeID() throws IOException {
        System.out.println("getEmployeeID");
        EmployeeDatabase instance = new EmployeeDatabase();
        EmployeeDatabase.addEmployee(testUser);
        String expResult = "123456";
        String result = instance.getEmployeeID(testUser);
        assertEquals(expResult, result);
    }

    /**
     * Test of find method, of class EmployeeDatabase.
     */
    @Test
    public void testFind() throws Exception {
        System.out.println("find");
        String employeeID = "";
        EmployeeDatabase instance = new EmployeeDatabase();
        User expResult = null;
        User result = instance.find(employeeID);
        assertEquals(expResult, result);
    }
    
}
