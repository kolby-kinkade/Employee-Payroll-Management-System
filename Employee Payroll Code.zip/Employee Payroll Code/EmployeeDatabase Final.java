package com.mycompany.paymanagementsys;

import java.io.*;
import java.util.*;
import java.io.Serializable;

/**
 *
 * @author kdkinkade
 */
public class EmployeeDatabase implements Serializable
{
    private static final long serialVersionUID = 4829402361785486983L;

    /**
     *
     */
    public static Set<User> userSet;
    
    /**
     * creates an EmployeeDatabase object
     * author@cdeets
     */
    public EmployeeDatabase() 
    {
        this.userSet = new HashSet<>();
    }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public boolean isUser(String username, String password)
    {
        for (User user : userSet) 
        {
            if (user.getUsername().equals(username) &&
                    user.getPassword().equals(password))
            {
                System.out.println(user.getUsername());
                System.out.println(username);
                System.out.println(user.getPassword());
                System.out.println(password);
                return true;
            }
            System.out.println(user.getUsername());
            System.out.println(username);
            System.out.println(user.getPassword());
            System.out.println(password);
        }
        return false;
    }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public boolean trueAdmin(String username, String password)
    {
        for (User user : userSet) {
            if (user.getUsername().equals(username) &&
                    user.getPassword().equals(password) &&
                    user.getIsAdmin() == true)
            {
                return true;
            }
        }
        return false;
    }
    
    /**
     *
     * @param user
     * @throws IOException
     */
    public static void addEmployee(User user) throws IOException 
    {
        if (!userSet.contains(user))
        {
            userSet.add(user);
        }
        else
        {
            throw new IllegalArgumentException("User already exists.");
        }
    }
    
    /**
     *
     * @param user
     * @return
     */
    public String getEmployeeID(User user)
    {
        return user.getEmployeeID();
    }
    
    /**
     *
     * @param employeeID
     * @return
     * @throws IOException
     */
    public User find(String employeeID)throws IOException
    {
        for (User user : userSet) {
            if (employeeID.equals(user.getEmployeeID()))
            {
                return user;
            }
        }
        return null;//return a message in a dialogue box "Employee not found"
    }
}
