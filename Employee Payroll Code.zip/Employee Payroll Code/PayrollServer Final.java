/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.paymanagementsys;

import static com.mycompany.paymanagementsys.EmployeeDatabase.userSet;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author kdkinkade
 */
public class PayrollServer2 implements Serializable
{

    /**
     *
     */
    public static final int PORT = 36250;

    /**
     *
     */
    public static boolean isVerified = false;

    /**
     *
     */
    public static boolean verifiedAdmin = false;

    /**
     *
     */
    public static final String FILENAME = "employeeSet.ser";
    
    /**
     *
     */
    public static EmployeeDatabase ed;
    
    //protected static User user1;

    /**
     *
     * @param args
     * @throws IOException
     * @throws ClassNotFoundException
     */
    
    public static void main(String[] args) throws IOException, ClassNotFoundException
    {
        System.out.println("KRAYC Payroll Services");
        
        ed = new EmployeeDatabase();
        ed = deserialize();
        
        if (userSet.isEmpty())
        {
            User user1 = new User("Chris Deets", "8675309", 2, "123-45-6789", 90000,
                0.22, "987654321", "USAA", "cdeets", "123456", "cdeets@marioBros.com",
                "Palomino Pass, Seguin, TX 78155", true, true, true, true, 80, 40, 
                80);
            ed.userSet.add(user1);
            serialize(ed);
        ed = deserialize();
            
        }
        
        //ed.addEmployee(user1);
        
        //if (!FILENAME.exists())
        
        for (int i = 0; i < ed.userSet.size(); i++)
        {
            System.out.println(ed.userSet + "\n");
            System.out.println(ed.userSet.size());
        }
        
        try 
        {
            ServerSocket welcomeSocket = new ServerSocket(PORT);
            System.out.printf("Server listening on port %d ...\n", PORT);
            
            while(true)
            {
                
                Socket connectSocket = welcomeSocket.accept(); 
                
                System.out.println("Client connected....");
                
                new Thread(() -> {
                    try {
                        handleUser(connectSocket);
                    } catch (IOException ex) {
                        Logger.getLogger(PayrollServer2.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(PayrollServer2.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }).start();
                
            }
        }
        catch (IOException e)
        {
            System.err.println(e);
        }
        finally
        {
            serialize(ed);
        }
    }
    
    
    
    private static void handleUser(Socket connectSocket) throws IOException, ClassNotFoundException
    {
       
        try
        {
            Scanner fromClient = new Scanner(connectSocket.getInputStream());
            PrintWriter toClient = new PrintWriter(connectSocket.getOutputStream());
            
            while (fromClient.hasNextLine())
            {
                String message = fromClient.nextLine();
                System.out.println(message);
                
                if (message.equals("0"))
                {
                    String clientUsername = fromClient.nextLine();
                    System.out.println(clientUsername);
                    String clientPassword = fromClient.nextLine();
                    System.out.println(clientPassword);


                    isVerified = verifyUser(clientUsername, clientPassword);
                    verifiedAdmin = verifyAdmin(clientUsername, clientPassword);
                    System.out.println(isVerified);

                    if (isVerified)
                    {
                        User verifiedUser = null;
                        
                        for (User user : ed.userSet)
                        {
                            if (user.getUsername().equals(clientUsername) &&
                                    user.getPassword().equals(clientPassword))                   
                            {
                                verifiedUser = user;
                            }
                            
                            if (verifiedUser != null)
                            {
                                toClient.println(verifiedUser.getName());
                                toClient.println(verifiedUser.getEmail());
                                toClient.println(verifiedUser.getEmployeeID());
                                toClient.println(verifiedUser.getUsername());
                                toClient.println(verifiedUser.getBankName());
                                toClient.println(verifiedUser.getBankAccountNum());
                                toClient.println(verifiedUser.getPositionNum());
                                toClient.println(verifiedUser.getSocialSecurityNum());
                                toClient.println(verifiedUser.getSalary());
                                toClient.println(verifiedUser.getTaxWithheld());
                                toClient.println(verifiedUser.getAddress());
                                toClient.println(verifiedUser.getLifeIns());
                                toClient.println(verifiedUser.getHealthIns());
                                toClient.println(verifiedUser.getRetirement());
                                toClient.println(verifiedUser.getVacationHours());
                                toClient.println(verifiedUser.getPersonalHours());
                                toClient.println(verifiedUser.getSickHours());
                                toClient.println(verifiedUser.getPassword());

                                toClient.flush();

                            }
                        }
                    }
                }
                else if (message.equals("5.1"))
                {
                    String newUsername = fromClient.nextLine();
                    System.out.println(newUsername);
                    String employeeId = fromClient.nextLine();
                    System.out.println(employeeId);

                    
                    for (User user : ed.userSet)
                    {
                        if (user.getEmployeeID().equals(employeeId))                   
                        {
                            user.setUsername(newUsername);
                        }
                    }
                    
                    serialize(ed);
                    System.out.println(userSet);    
                }
                else if (message.equals("5.2"))
                {
                    String password1 = fromClient.nextLine();
                    System.out.println(password1);
                    String employeeId = fromClient.nextLine();
                    System.out.println(employeeId);

                    
                    for (User user : ed.userSet)
                    {
                        if (user.getEmployeeID().equals(employeeId))                   
                        {
                            user.setPassword(password1);
                        }
                    }
                    
                    serialize(ed);
                    System.out.println(userSet);    
                }
                else if (message.equals("10"))
                {
                    System.out.println("New Employee Screen Visible");
                    
                    String newName = fromClient.nextLine();
                    System.out.println(newName);
                    
                    String newBank = fromClient.nextLine();
                    System.out.println(newBank);

                    String newBankAccountNum = fromClient.nextLine();
                    System.out.println(newBankAccountNum);

                    String newEmployeeID = fromClient.nextLine();
                    System.out.println(newEmployeeID);

                    String newSSN =  fromClient.nextLine();
                    System.out.println(newSSN);

                    String newEmail = fromClient.nextLine();
                    System.out.println(newEmail);

                    String newAddress = fromClient.nextLine();
                    System.out.println(newAddress);

                    double newVacation = Double.parseDouble(fromClient.nextLine());
                    System.out.println(newVacation);

                    double newPersonal = Double.parseDouble(fromClient.nextLine());
                    System.out.println(newPersonal);

                    double newSick = Double.parseDouble(fromClient.nextLine());
                    System.out.println(newSick);

                    boolean newHealth = Boolean.parseBoolean(fromClient.nextLine());
                    System.out.println(newHealth);

                    boolean newLife = Boolean.parseBoolean(fromClient.nextLine());
                    System.out.println(newLife);

                    boolean newRetirement = Boolean.parseBoolean(fromClient.nextLine());
                    System.out.println(newRetirement);

                    boolean newAdmin = Boolean.parseBoolean(fromClient.nextLine());
                    System.out.println(newAdmin);

                    String newUsername = fromClient.nextLine();
                    System.out.println(newUsername);

                    String newPassword = fromClient.nextLine();
                    System.out.println(newPassword);


                    User newUser = new User(newName, newEmployeeID, 0, newSSN, 0, 0, newBankAccountNum, newBank, newUsername,
                            newPassword, newEmail, newAddress, newLife, newHealth, newRetirement, newAdmin, newVacation, newPersonal,
                            newSick);
                    
                    ed.userSet.add(newUser);
                    serialize(ed);
                    //deserialize();
                    System.out.println(userSet);
 
                }
                else
                {
                    System.out.println("User does not have access.");
                }
            }
        } 
        catch (IOException e)
        {
            System.err.println(e);
        }
        
        finally
        {
            try
            {
                connectSocket.close();
            }
            catch (IOException e)
            {
                System.err.println(e);
            }
        }
    }
    
    /**
     *
     * @param user
     * @return
     */
    public String getName(User user)
        {
            return user.getName();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getEmail(User user)
        {
            return user.getEmail();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getEmployeeID(User user)
        {
            return user.getEmployeeID();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getUsername(User user)
        {
            return user.getUsername();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getBankName(User user)
        {
            return user.getBankName();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getBankAccountNum(User user)
        {
            return user.getBankAccountNum();
        }

    /**
     *
     * @param user
     * @return
     */
    public int getPositionNum(User user)
        {
            return user.getPositionNum();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getSocialSecurityNum(User user)
        {
            return user.getSocialSecurityNum();
        }

    /**
     *
     * @param user
     * @return
     */
    public double getSalary(User user)
        {
            return user.getSalary();
        }

    /**
     *
     * @param user
     * @return
     */
    public double getTaxWithheld(User user)
        {
            return user.getTaxWithheld();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getAddress(User user)
        {
            return user.getAddress();
        }

    /**
     *
     * @param user
     * @return
     */
    public boolean getLifeIns(User user)
        {
            return user.getLifeIns();
        }

    /**
     *
     * @param user
     * @return
     */
    public boolean getHealthIns(User user)
        {
            return user.getHealthIns();
        }

    /**
     *
     * @param user
     * @return
     */
    public boolean getRetirement(User user)
        {
            return user.getRetirement();
        }

    /**
     *
     * @param user
     * @return
     */
    public double getVacationHours(User user)
        {
            return user.getVacationHours();
        }

    /**
     *
     * @param user
     * @return
     */
    public double getPersonalHours(User user)
        {
            return user.getPersonalHours();
        }

    /**
     *
     * @param user
     * @return
     */
    public double getSickHours(User user)
        {
            return user.getSickHours();
        }

    /**
     *
     * @param user
     * @return
     */
    public String getPassword(User user)
        {
            return user.getPassword();
        }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public static boolean verifyUser(String username, String password)
    {
        return ed.isUser(username, password);
    }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public static boolean verifyAdmin(String username, String password)
    {
        return ed.trueAdmin(username, password);
    }
    
    /**
     *
     * @param ed
     * @throws IOException
     */
    public static void serialize(EmployeeDatabase ed) throws IOException
    {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILENAME)))
        {
            oos.writeObject(ed);
            System.out.println("Serialization confirmed");
        } 
        catch (IOException e)
        {
            System.err.println("Error serializing database file: " +
                e.getMessage());
        }
    }      
    
    /**
     *
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static EmployeeDatabase deserialize() throws IOException, ClassNotFoundException
    {
        EmployeeDatabase db = null;
        
        try
        {
            File file = new File(FILENAME);
            if (!file.exists())
            {
                file.createNewFile();
                System.out.println("Creating new file: " + FILENAME);
            }
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) 
            {

                db = (EmployeeDatabase) ois.readObject();
                System.out.println("Deserialization confirmed");
            }
        }
        catch (IOException | ClassNotFoundException e)
        {
            System.err.println("Could not deserialize file: " + e.getMessage());
            db = new EmployeeDatabase();

        }
        
    return db;
    }   
}
