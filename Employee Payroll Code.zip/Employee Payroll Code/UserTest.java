/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.paymanagementsys;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


/**
 *
 * @author kdkinkade
 */
public class UserTest {
    
    private User testUser = new User("John Doe", "123456", 1, "545-85-7894",
        90000, .24, "654321", "USSSA", "johnDoe1", "johnTheDeer1",
        "john.doe@mariobros.com", "42 Wallaby Way, Sydney 78910", true, false,
        true, false, 80, 40, 80);
    
    public UserTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getName method, of class User.
     */
    @Test
    public void testGetName() {
        testUser.setName("P. Sherman");
        
        assertEquals("P. Sherman", testUser.getName());
    }

    /**
     * Test of getEmployeeID method, of class User.
     */
    @Test
    public void testGetEmployeeID() {
        testUser.setEmployeeID("1234567");
        
        assertEquals("1234567", testUser.getEmployeeID());
    }

    /**
     * Test of getPositionNum method, of class User.
     */
    @Test
    public void testGetPositionNum() {
        testUser.setPositionNum(3);
        
        assertEquals(3, testUser.getPositionNum());
    }

    /**
     * Test of getSocialSecurityNum method, of class User.
     */
    @Test
    public void testGetSocialSecurityNum() {
        testUser.setSocialSecurityNum("123-45-6789");
        
        assertEquals("123-45-6789", testUser.getSocialSecurityNum());
    }

    /**
     * Test of getSalary method, of class User.
     */
    @Test
    public void testGetSalary() {
        testUser.setSalary(90000.00);
        
        assertEquals(90000.00, testUser.getSalary());
    }

    /**
     * Test of getTaxWithheld method, of class User.
     */
    @Test
    public void testGetTaxWithheld() {
        testUser.setTaxWithheld(0.22);
        
        assertEquals(0.22, testUser.getTaxWithheld());
    }

    /**
     * Test of getbankName method, of class User.
     */
    @Test
    public void testGetbankName() {
        testUser.setBankName("Chase Bank");
        
        assertEquals("Chase Bank", testUser.getBankName());
    }

    /**
     * Test of getUsername method, of class User.
     */
    @Test
    public void testGetUsername() {
        testUser.setUsername("Dory4");
        
        assertEquals("Dory4", testUser.getUsername());
    }

    /**
     * Test of getPassword method, of class User.
     */
    @Test
    public void testGetPassword() {
        testUser.setPassword("justKeepSwimming4");
        
        assertEquals("justKeepSwimming4", testUser.getPassword());
    }

    /**
     * Test of getEmail method, of class User.
     */
    @Test
    public void testGetEmail() {
        testUser.setEmail("findingDory4@mariobros.com");
        
        assertEquals("findingDory4@mariobros.com", testUser.getEmail());
    }

    /**
     * Test of getAddress method, of class User.
     */
    @Test
    public void testGetAddress() {
        testUser.setAddress("42 Boat by the Docks, Sydney 78910");
        
        assertEquals("42 Boat by the Docks, Sydney 78910", testUser.getAddress());
    }

    /**
     * Test of getLifeIns method, of class User.
     */
    @Test
    public void testGetLifeIns() {
        testUser.setLifeIns(false);
        
        assertEquals(false, testUser.getLifeIns());
    }

    /**
     * Test of getHealthIns method, of class User.
     */
    @Test
    public void testGetHealthIns() {
        testUser.setHealthIns(false);
        
        assertEquals(false, testUser.getHealthIns());
    }

    /**
     * Test of getRetirement method, of class User.
     */
    @Test
    public void testGetRetirement() {
        testUser.setRetirement(false);
        
        assertEquals(false, testUser.getRetirement());
    }

    /**
     * Test of getIsAdmin method, of class User.
     */
    @Test
    public void testGetIsAdmin() {
        testUser.setIsAdmin(false);
        
        assertEquals(false, testUser.getIsAdmin());
    }

    /**
     * Test of getVacationHours method, of class User.
     */
    @Test
    public void testGetVacationHours() {
        testUser.setVacationHours(80.00);
        
        assertEquals(80.00, testUser.getVacationHours());
    }

    /**
     * Test of getPersonalHours method, of class User.
     */
    @Test
    public void testGetPersonalHours() {
        testUser.setPersonalHours(40.00);
        
        assertEquals(40.00, testUser.getPersonalHours());
    }

    /**
     * Test of getSickHours method, of class User.
     */
    @Test
    public void testGetSickHours() {
        testUser.setSickHours(80.00);
        
        assertEquals(80.00, testUser.getSickHours());
    }
}
